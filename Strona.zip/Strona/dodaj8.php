<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_POST['url'],$_POST['producentP'],$_POST['nazwaP'],$_POST['seriaP'],$_POST['cenaP'],$_POST['modelP'],$_POST['iloscP'],$_POST['opisP']))	
	{
		$url = $_POST['url'];
		$producentP = $_POST['producentP'];
		$nazwaP = $_POST['nazwaP'];
		$seriaP = $_POST['seriaP'];
		$cenaP = $_POST['cenaP'];
		$modelP = $_POST['modelP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		mysqli_query($polaczenie, "INSERT INTO `gpu` (`id_kategoria`,`id_producent`,`nazwa`,`cena`,`seria`,`model`,`zdjecie`,`opis`,`ilosc`) VALUES
		('9','$producentP','$nazwaP','$cenaP','$seriaP','$modelP','$url','$opisP','$iloscP');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Url zdjecie:<br /><input type="text" name="url" ><br />
		id producent:<br /><input type="text" name="producentP" ><br />
		nazwa:<br /><input type="text" name="nazwaP" ><br /><br />
		seria:<br /><input type="text" name="seriaP" ><br /><br />
		cena:<br /><input type="text" name="cenaP" ><br /><br />
		model:<br /><input type="text" name="modelP" ><br /><br />
		ilosc:<br /><input type="text" name="iloscP" ><br /><br />
		opis:<br /><input type="text" name="opisP" ><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>