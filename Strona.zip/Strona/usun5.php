<?php
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: logowanie.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	require_once "connect.php";	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	


	if(isset($_GET['idn5'])) 
	{
		$idn5=$_GET['idn5'];
		//echo $idn; 
		mysqli_query($polaczenie,"DELETE FROM komputery WHERE id_komputer='$idn5'");

	}
	else if(!isset($_GET['idn5']))
	{
		header('Location: admin.php');
		exit();
	}

?>