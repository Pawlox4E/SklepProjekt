<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_POST['kategoriaP'],$_POST['producentP'],$_POST['nazwaP'],$_POST['kolorP'],$_POST['cenaP'],$_POST['iloscP'],$_POST['opisP'],$_POST['url']))	
	{
		$id_peryferiaP = $id_peryferia;
		$kategoriaP = $_POST['kategoriaP'];
		$producentP = $_POST['producentP'];
		$nazwaP = $_POST['nazwaP'];
		$kolorP = $_POST['kolorP'];
		$cenaP = $_POST['cenaP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		$url = $_POST['url'];
		mysqli_query($polaczenie, "INSERT INTO `peryferia` (`id_kategoria`, `nazwa`, `id_kolor`, `id_producent`, `cena`, `ilosc`, `opis`, `zdjecie`) VALUES 
		('$kategoriaP', '$nazwaP', '$kolorP', '$producentP', '$cenaP', '$iloscP', '$opisP', '$url');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		id kategoria:<br /><input type="text" name="kategoriaP" ><br />
		id producent:<br /><input type="text" name="producentP" ><br />
		nazwa:<br /><input type="text" name="nazwaP" ><br /><br />
		id kolor:<br /><input type="text" name="kolorP" ><br /><br />
		cena:<br /><input type="text" name="cenaP" ><br /><br />
		ilosc:<br /><input type="text" name="iloscP" ><br /><br />
		opis:<br /><input type="text" name="opisP" ><br /><br />
		Url zdjeica:<br /><input type="text" name="url" ><br />
		<input type="submit" value="zapisz">
	</form>
</body>