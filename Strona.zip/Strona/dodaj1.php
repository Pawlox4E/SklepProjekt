<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';

	if(isset($_POST['producent'],$_POST['email'],$_POST['telefon'],$_POST['miejscowosc'],$_POST['ulica'],$_POST['numer']))	
	{
		$producent= $_POST['producent'];
		$email = $_POST['email'];
		$telefon = $_POST['telefon'];
		$miejscowosc = $_POST['miejscowosc'];
		$ulica = $_POST['ulica'];
		$numer = $_POST['numer'];
		mysqli_query($polaczenie, "INSERT INTO `producenci` (`producent`,`email`,`telefon`,`miejscowosc`,`ulica`,`numer`) VALUES
								('$producent','$email','$telefon','$miejscowosc','$ulica','$numer');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Producent:<br /><input type="text" name="producent" ><br />
		Email:<br /><input type="text" name="email" ><br />
		telefon:<br /><input type="text" name="telefon"><br /><br />
		miejscowosc:<br /><input type="text" name="miejscowosc" ><br /><br />
		ulica:<br /><input type="text" name="ulica" ><br /><br />
		numer:<br /><input type="text" name="numer" ><br /><br />
		<input type="submit" value="dodaj">
	</form>
</body>