<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_GET['ident2']))
	{
		$num=$_GET['ident2'];

		$wybierz = mysqli_query($polaczenie, "SELECT id_kolor, kolor, hex FROM kolory WHERE id_kolor='$num'");
		$liczba_rekordow = mysqli_num_rows($wybierz);
		while ($wynik = @mysqli_fetch_array($wybierz,  MYSQLI_ASSOC)) {
			$id_kolor=$wynik['id_kolor'];
			$kolor=$wynik['kolor'];
			$hex=$wynik['hex'];
		}
	}
	if(isset($_POST['kolorP'],$_POST['hexP']))	
	{
		$id_kolorP = $id_kolor;
		$kolorP = $_POST['kolorP'];
		$hexP = $_POST['hexP'];
		mysqli_query($polaczenie, "UPDATE kolory SET kolor='$kolorP', hex='$hexP' WHERE id_kolor=$id_kolorP;");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Id:<br /><input id="ident2" type="text" name="id_kolorP" Value='<?php echo $id_kolor;?>' disabled><br />
		Kolor:<br /><input type="text" name="kolorP" Value='<?php echo $kolor;?>'><br />
		Hex:<br /><input type="text" name="hexP" Value='<?php echo $hex;?>'><br />
		<input type="submit" value="zapisz">
	</form>
</body>