$(".edytuj1").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn1 = $wynik.find(".nr1").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj1.php',
	data1:'idn1='+$idn1,
	success: function(data1) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		window.open('edytuj1.php?ident1='+$idn1);
	}	
	});
});

$(".usun1").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn1 = $wynik.find(".nr1").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun1.php',
	data1:'idn1='+$idn1,
	success: function(data1) {
	//$('#ident').html(data);
	//setTimeout(function(){
	//$( "#admintable1" ).load( "admin.php #admintable1" );
	//}, 500);
	window.open('usun1.php?ident1='+$idn1);
	}
	});
		
});

$(".edytuj2").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn2 = $wynik.find(".nr2").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj2.php',
	data2:'idn2='+$idn2,
	success: function(data2) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj2.php?ident2='+$idn2);
	}	
	});
});

$(".usun2").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn2 = $wynik.find(".nr2").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun2.php',
	data2:'idn2='+$idn2,
	success: function(data2) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable2" ).load( "admin.php #admintable2" );
	}, 500); 
	}
	});
		
});

$(".edytuj3").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn3 = $wynik.find(".nr3").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj3.php',
	data3:'idn3='+$idn3,
	success: function(data3) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj3.php?ident3='+$idn3);
	}	
	});
});

$(".usun3").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn3 = $wynik.find(".nr3").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun3.php',
	data3:'idn3='+$idn3,
	success: function(data3) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable3" ).load( "admin.php #admintable3" );
	}, 500); 
	}
	});
		
});

$(".edytuj4").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn4 = $wynik.find(".nr4").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj4.php',
	data4:'idn4='+$idn4,
	success: function(data4) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj4.php?ident4='+$idn4);
	}	
	});
});

$(".usun4").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn4 = $wynik.find(".nr4").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun4.php',
	data4:'idn4='+$idn4,
	success: function(data4) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable4" ).load( "admin.php #admintable4" );
	}, 500); 
	}
	});
		
});

$(".edytuj5").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn5 = $wynik.find(".nr5").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj5.php',
	data5:'idn5='+$idn5,
	success: function(data5) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj5.php?ident5='+$idn5);
	}	
	});
});

$(".usun5").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn5 = $wynik.find(".nr5").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun5.php',
	data5:'idn5='+$idn5,
	success: function(data5) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable5" ).load( "admin.php #admintable5" );
	}, 500); 
	}
	});
		
});

$(".edytuj6").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn6 = $wynik.find(".nr6").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj6.php',
	data6:'idn6='+$idn6,
	success: function(data6) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj6.php?ident6='+$idn6);
	}	
	});
});

$(".usun6").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn6 = $wynik.find(".nr6").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun6.php',
	data6:'idn6='+$idn6,
	success: function(data6) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable6" ).load( "admin.php #admintable6" );
	}, 500); 
	}
	});
		
});

$(".edytuj7").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn7 = $wynik.find(".nr7").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj7.php',
	data7:'idn7='+$idn7,
	success: function(data7) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj7.php?ident7='+$idn7);
	}	
	});
});

$(".usun7").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn7 = $wynik.find(".nr7").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun7.php',
	data7:'idn7='+$idn7,
	success: function(data7) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable7" ).load( "admin.php #admintable7" );
	}, 500); 
	}
	});
		
});

$(".edytuj8").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn8 = $wynik.find(".nr8").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj8.php',
	data8:'idn8='+$idn8,
	success: function(data8) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj8.php?ident8='+$idn8);
	}	
	});
});

$(".usun8").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn8 = $wynik.find(".nr8").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun8.php',
	data8:'idn8='+$idn8,
	success: function(data8) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable8" ).load( "admin.php #admintable8" );
	}, 500); 
	}
	});
		
});

$(".edytuj9").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn9 = $wynik.find(".nr9").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj9.php',
	data9:'idn9='+$idn9,
	success: function(data9) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj9.php?ident9='+$idn9);
	}	
	});
});

$(".usun9").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn9 = $wynik.find(".nr9").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun9.php',
	data9:'idn9='+$idn9,
	success: function(data9) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable9" ).load( "admin.php #admintable9" );
	}, 500); 
	}
	});
		
});

$(".edytuj10").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn10 = $wynik.find(".nr10").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj10.php',
	data10:'idn10='+$idn10,
	success: function(data10) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj10.php?ident10='+$idn10);
	}	
	});
});

$(".usun10").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn10 = $wynik.find(".nr10").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun10.php',
	data10:'idn10='+$idn10,
	success: function(data10) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable10" ).load( "admin.php #admintable10" );
	}, 500); 
	}
	});
		
});

$(".edytuj11").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn11 = $wynik.find(".nr11").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj11.php',
	data11:'idn11='+$idn11,
	success: function(data11) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj11.php?ident11='+$idn11);
	}	
	});
});

$(".usun11").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn11 = $wynik.find(".nr11").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun11.php',
	data11:'idn11='+$idn11,
	success: function(data11) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable11" ).load( "admin.php #admintable11" );
	}, 500); 
	}
	});
		
});

$(".edytuj12").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn12 = $wynik.find(".nr12").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj12.php',
	data12:'idn12='+$idn12,
	success: function(data12) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj12.php?ident12='+$idn12);
	}	
	});
});

$(".usun12").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn12 = $wynik.find(".nr12").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun12.php',
	data12:'idn12='+$idn12,
	success: function(data12) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable12" ).load( "admin.php #admintable12" );
	}, 500); 
	}
	});
		
});

$(".edytuj13").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn13 = $wynik.find(".nr13").text(); // Find the text
	//alert($idn); //dobrze do tąd
	
	$.ajax({	
	url:'edytuj13.php',
	data12:'idn13='+$idn13,
	success: function(data13) {
		//$('#ident').html(data);
		//var win = window.open();
		//win.document.write(data);
		 window.open('edytuj13.php?ident13='+$idn13);
	}	
	});
});

$(".usun13").click(function() {
    var $wynik = $(this).closest("tr");    // Find the wynik
    var $idn13 = $wynik.find(".nr13").text(); // Find the text
	//alert($idn);
	
	$.ajax({	
	url:'usun13.php',
	data12:'idn13='+$idn13,
	success: function(data13) {
	//$('#ident').html(data);
	setTimeout(function(){
	$( "#admintable13" ).load( "admin.php #admintable13" );
	}, 500); 
	}
	});
		
});



$("#odswiez").click(function(){
{
	setTimeout(function() 
  {
    location.reload();  //Refresh page
  }, 1000);
}
});