<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_POST['url'],$_POST['producentP'],$_POST['nazwaP'],$_POST['pojemnoscP'],$_POST['cenaP'],$_POST['interfejsP'],$_POST['typP'],$_POST['formatP'],$_POST['iloscP'],$_POST['opisP']))	
	{

		$producentP = $_POST['producentP'];
		$nazwaP = $_POST['nazwaP'];
		$pojemnoscP = $_POST['pojemnoscP'];
		$cenaP = $_POST['cenaP'];
		$interfejsP = $_POST['interfejsP'];
		$typP = $_POST['typP'];
		$formatP = $_POST['formatP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		$url = $_POST['url'];
		mysqli_query($polaczenie, "INSERT INTO `dysk` (`id_kategoria`,`id_producent`,`nazwa`,`cena`,`pojemnosc`,`interfejs`,`typ`,`format`,`zdjecie`,`opis`,`ilosc`) VALUES
		('11','$producentP','$nazwaP','$cenaP','$pojemnoscP','$interfejsP','$typP','$formatP','$url','$opisP','$iloscP');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		id producent:<br /><input type="text" name="producentP" ><br />
		nazwa:<br /><input type="text" name="nazwaP" ><br /><br />
		pojemnosc:<br /><input type="text" name="pojemnoscP" ><br /><br />
		cena:<br /><input type="text" name="cenaP" ><br /><br />
		interfejs:<br /><input type="text" name="interfejsP" ><br /><br />
		typ:<br /><input type="text" name="typP" ><br />
		format:<br /><input type="text" name="formatP" ><br />
		ilosc:<br /><input type="text" name="iloscP"><br /><br />
		opis:<br /><input type="text" name="opisP" ><br /><br />
		Url zdjecia:<br /><input type="text" name="url" ><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>