<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_GET['ident7']))
	{
		$num=$_GET['ident7'];

		$wybierz = mysqli_query($polaczenie, "SELECT id_dysk, id_kategoria, id_producent, nazwa, pojemnosc, cena, interfejs, typ, format, ilosc, opis FROM dysk WHERE id_dysk='$num'");
		$liczba_rekordow = mysqli_num_rows($wybierz);
		while ($wynik = @mysqli_fetch_array($wybierz,  MYSQLI_ASSOC)) {
			$id_dysk=$wynik['id_dysk'];
			$kategoria=$wynik['id_kategoria'];
			$producent=$wynik['id_producent'];
			$nazwa=$wynik['nazwa'];
			$pojemnosc=$wynik['pojemnosc'];
			$cena=$wynik['cena'];
			$interfejs=$wynik['interfejs'];
			$typ=$wynik['typ'];
			$format=$wynik['format'];
			$ilosc=$wynik['ilosc'];
			$opis=$wynik['opis'];
		}
	}
	if(isset($_POST['kategoriaP'],$_POST['producentP'],$_POST['nazwaP'],$_POST['pojemnoscP'],$_POST['cenaP'],$_POST['interfejsP'],$_POST['typP'],$_POST['formatP'],$_POST['iloscP'],$_POST['opisP']))	
	{
		$id_dyskP = $id_dysk;
		$kategoriaP = $_POST['kategoriaP'];
		$producentP = $_POST['producentP'];
		$nazwaP = $_POST['nazwaP'];
		$pojemnoscP = $_POST['pojemnoscP'];
		$cenaP = $_POST['cenaP'];
		$interfejsP = $_POST['interfejsP'];
		$typP = $_POST['typP'];
		$formatP = $_POST['formatP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		mysqli_query($polaczenie, "UPDATE dysk SET id_kategoria='$kategoriaP', id_producent='$producentP', nazwa='$nazwaP', pojemnosc='$pojemnoscP', cena='$cenaP', interfejs='$interfejsP', typ='$typP', format='$formatP', ilosc='$iloscP', opis='$opisP' WHERE id_dysk=$id_dyskP;");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Id:<br /><input id="ident7" type="text" name="id_dyskP" Value='<?php echo $id_dysk;?>' disabled><br />
		id kategoria:<br /><input type="text" name="kategoriaP" Value='<?php echo $kategoria;?>'><br />
		id producent:<br /><input type="text" name="producentP" Value='<?php echo $producent;?>'><br />
		nazwa:<br /><input type="text" name="nazwaP" Value='<?php echo $nazwa;?>'><br /><br />
		pojemnosc:<br /><input type="text" name="pojemnoscP" Value='<?php echo $pojemnosc;?>'><br /><br />
		cena:<br /><input type="text" name="cenaP" Value='<?php echo $cena;?>'><br /><br />
		interfejs:<br /><input type="text" name="interfejsP" Value='<?php echo $interfejs;?>'><br /><br />
		typ:<br /><input type="text" name="typP" Value='<?php echo $typ;?>'><br />
		format:<br /><input type="text" name="formatP" Value='<?php echo $format;?>'><br />
		ilosc:<br /><input type="text" name="iloscP" Value='<?php echo $ilosc;?>'><br /><br />
		opis:<br /><input type="text" name="opisP" Value='<?php echo $opis;?>'><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>