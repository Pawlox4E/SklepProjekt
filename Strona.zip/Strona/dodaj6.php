<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_POST['url'],$_POST['producentP'],$_POST['nazwaP'],$_POST['pojemnoscP'],$_POST['cenaP'],$_POST['modułyP'],$_POST['typP'],$_POST['taktowanieP'],$_POST['iloscP'],$_POST['opisP']))	
	{
		$producentP = $_POST['producentP'];
		$nazwaP = $_POST['nazwaP'];
		$pojemnoscP = $_POST['pojemnoscP'];
		$cenaP = $_POST['cenaP'];
		$modułyP = $_POST['modułyP'];
		$typP = $_POST['typP'];
		$taktowanieP = $_POST['taktowanieP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		$url = $_POST['url'];
		mysqli_query($polaczenie, "INSERT INTO `ram` (`id_kategoria`,`id_producent`,`nazwa`,`cena`,`pojemnosc`,`moduły`,`typ`,`taktowanie`,`zdjecie`,`opis`,`ilosc`) VALUES
		('10','$producentP','$nazwaP','$cenaP','$pojemnoscP','$modułyP','$typP','$taktowanieP','$url','$opisP','$iloscP');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		id producent:<br /><input type="text" name="producentP" ><br />
		nazwa:<br /><input type="text" name="nazwaP" ><br /><br />
		pojemnosc:<br /><input type="text" name="pojemnoscP" ><br /><br />
		cena:<br /><input type="text" name="cenaP" ><br /><br />
		moduły:<br /><input type="text" name="modułyP" ><br /><br />
		typ:<br /><input type="text" name="typP" ><br />
		taktowanie:<br /><input type="text" name="taktowanieP" ><br />
		ilosc:<br /><input type="text" name="iloscP" ><br /><br />
		opis:<br /><input type="text" name="opisP" ><br /><br />
		Url zdjecia:<br /><input type="text" name="url" ><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>