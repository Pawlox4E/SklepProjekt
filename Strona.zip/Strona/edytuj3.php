<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_GET['ident3']))
	{
		$num=$_GET['ident3'];

		$wybierz = mysqli_query($polaczenie, "SELECT id_kategoria, nazwa FROM kategorie WHERE id_kategoria='$num'");
		$liczba_rekordow = mysqli_num_rows($wybierz);
		while ($wynik = @mysqli_fetch_array($wybierz,  MYSQLI_ASSOC)) {
			$id_kategoria=$wynik['id_kategoria'];
			$nazwa=$wynik['nazwa'];

		}
	}
	if(isset($_POST['nazwaP']))	
	{
		$id_kategoriaP = $id_kategoria;
		$nazwaP = $_POST['nazwaP'];
		mysqli_query($polaczenie, "UPDATE kategorie SET nazwa='$nazwaP' WHERE id_kategoria=$id_kategoriaP;");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Id:<br /><input id="ident3" type="text" name="id_kategoriaP" Value='<?php echo $id_kategoria;?>' disabled><br />
		Nazwa:<br /><input type="text" name="nazwaP" Value='<?php echo $nazwa;?>'><br />
		<input type="submit" value="zapisz">
	</form>
</body>