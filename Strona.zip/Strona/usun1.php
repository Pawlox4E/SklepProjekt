<?php
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: logowanie.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	require_once "connect.php";	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	


	if(isset($_GET['ident1'])) 
	{
		$num=$_GET['ident1'];
		//echo $idn; 
		mysqli_query($polaczenie,"DELETE * FROM producenci WHERE id_producent='$num'");

	}
	else if(!isset($_GET['iden1']))
	{
		header('Location: admin.php');
		exit();
	}

?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
Usunieto!

</body>