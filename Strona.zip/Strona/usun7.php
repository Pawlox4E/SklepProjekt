<?php
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: logowanie.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	require_once "connect.php";	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	


	if(isset($_GET['idn7'])) 
	{
		$idn7=$_GET['idn7'];
		//echo $idn; 
		mysqli_query($polaczenie,"DELETE FROM dysk WHERE id_dysk='$idn7'");

	}
	else if(!isset($_GET['idn7']))
	{
		header('Location: admin.php');
		exit();
	}

?>