<?php
	$host = "localhost";
	$db_user = "root";
	$db_password = "";
	$db_name = "sklep";
?>