<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';

	if(isset($_POST['nazwaP'],$_POST['id_cpuP'],$_POST['id_ramP'],$_POST['id_gpuP'],$_POST['id_moboP'],$_POST['id_zasilaczP'],$_POST['id_dyskP'],$_POST['id_obudowaP'],$_POST['cenaP'],$_POST['iloscP'],$_POST['opisP'],$_POST['dodatkiP']))	
	{
		$nazwaP = $_POST['nazwaP'];
		$id_cpuP = $_POST['id_cpuP'];
		$id_ramP = $_POST['id_ramP'];
		$id_gpuP = $_POST['id_gpuP'];
		$id_moboP = $_POST['id_moboP'];
		$id_zasilaczP = $_POST['id_zasilaczP'];
		$id_dyskP = $_POST['id_dyskP'];
		$id_obudowaP = $_POST['id_obudowaP'];
		$cenaP= $_POST['cenaP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		$dodatkiP = $_POST['dodatkiP'];
		mysqli_query($polaczenie, "INSERT INTO `komputery` (`id_kategoria`, `nazwa`, `id_cpu`, `id_gpu`, `id_ram`, `id_mobo`, `id_zasilacz`, `id_dysk`, `id_obudowa`, `cena`, `ilosc`, `opis`, `dodatki`) VALUES 
		('1', '$nazwaP', '$id_cpuP','$id_gpuP', '$id_ramP', '$id_moboP', '$id_zasilaczP', '$id_dyskP', '$id_obudowaP', '$cenaP', '$iloscP', '$opisP', '$dodatkiP');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		nazwa:<br /><input type="text" name="nazwaP"><br />
		Id cpu:<br /><input type="text" name="id_cpuP"><br /><br />
		Id ram:<br /><input type="text" name="id_ramP"><br /><br />
		Id gpu:<br /><input type="text" name="id_gpuP"><br /><br />
		Id mobo:<br /><input type="text" name="id_moboP"><br /><br />
		Id zasilacz:<br /><input type="text" name="id_zasilaczP"><br /><br />
		Id dysk:<br /><input type="text" name="id_dyskP"><br />
		Id obudowa:<br /><input type="text" name="id_obudowaP"><br />
		cena:<br /><input type="text" name="cenaP"><br /><br />
		ilosc:<br /><input type="text" name="iloscP"><br /><br />
		opis:<br /><input type="text" name="opisP"><br /><br />
		dodatki:<br /><input type="text" name="dodatkiP"><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>