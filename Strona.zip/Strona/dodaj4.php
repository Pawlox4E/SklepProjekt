<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_POST['producentP'],$_POST['nazwaP'],$_POST['kolorP'],$_POST['cenaP'],$_POST['rozmiar_ekranuP'],$_POST['rozdzielczosc_ekranuP'],$_POST['pamiec_flashP'],$_POST['pamiec_ramP'],$_POST['iloscP'],$_POST['opisP'],$_POST['url']))	
	{
		$producentP = $_POST['producentP'];
		$nazwaP = $_POST['nazwaP'];
		$kolorP = $_POST['kolorP'];
		$cenaP = $_POST['cenaP'];
		$rozmiar_ekranuP = $_POST['rozmiar_ekranuP'];
		$rozdzielczosc_ekranuP = $_POST['rozdzielczosc_ekranuP'];
		$pamiec_flashP = $_POST['pamiec_flashP'];
		$pamiec_ramP = $_POST['pamiec_ramP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		$url = $_POST['url'];
		mysqli_query($polaczenie, "INSERT INTO `telefony` (`id_kategoria`,`id_producent`,`nazwa`,`id_kolor`,`cena`,`rozmiar_ekranu`,`rozdzielczosc_ekranu`,`pamiec_flash`,`pamiec_ram`,`ilosc`,`opis`,`zdjecie`) VALUES
		('7','$producentP','$nazwaP','$kolorP','$cenaP','$rozmiar_ekranuP','$rozdzielczosc_ekranuP','$pamiec_flashP','$pamiec_ramP','$iloscP','$opisP','$url');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		id producent:<br /><input type="text" name="producentP" ><br />
		nazwa:<br /><input type="text" name="nazwaP" ><br /><br />
		id kolor:<br /><input type="text" name="kolorP" ><br /><br />
		cena:<br /><input type="text" name="cenaP" ><br /><br />
		rozmiar_ekranu:<br /><input type="text" name="rozmiar_ekranuP" ><br /><br />
		rozdzielczosc_ekranu:<br /><input type="text" name="rozdzielczosc_ekranuP" ><br />
		pamiec_flash:<br /><input type="text" name="pamiec_flashP" ><br />
		pamiec_ram:<br /><input type="text" name="pamiec_ramP" ><br /><br />
		ilosc:<br /><input type="text" name="iloscP" ><br /><br />
		opis:<br /><input type="text" name="opisP" ><br /><br />
		Url zdj:<br /><input type="text" name="url" ><br />
		<input type="submit" value="zapisz">
	</form>
</body>