<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';

	if(isset($_POST['url'],$_POST['producentP'],$_POST['nazwaP'],$_POST['kolorP'],$_POST['cenaP'],$_POST['rozmiarP'],$_POST['iloscP'],$_POST['opisP']))	
	{
		$url = $_POST['url'];
		$producentP = $_POST['producentP'];
		$nazwaP = $_POST['nazwaP'];
		$kolorP = $_POST['kolorP'];
		$cenaP = $_POST['cenaP'];
		$rozmiarP = $_POST['rozmiarP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		mysqli_query($polaczenie, "INSERT INTO `obudowa` (`id_kategoria`,`id_producent`,`nazwa`,`id_kolor`,`cena`,`rozmiar`,`zdjecie`,`opis`,`ilosc`) VALUES
		('13','$producentP','$nazwaP','$kolorP','$cenaP','$rozmiarP','$url','$opisP','$iloscP');");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Url zdjecia:<br /><input type="text" name="url" ><br />
		id producent:<br /><input type="text" name="producentP"><br />
		nazwa:<br /><input type="text" name="nazwaP" ><br /><br />
		id kolor:<br /><input type="text" name="kolorP" ><br /><br />
		cena:<br /><input type="text" name="cenaP" ><br /><br />
		rozmiar:<br /><input type="text" name="rozmiarP" ><br /><br />
		ilosc:<br /><input type="text" name="iloscP" ><br /><br />
		opis:<br /><input type="text" name="opisP" ><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>