<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_GET['ident1']))
	{
		$num=$_GET['ident1'];

		$wybierz = mysqli_query($polaczenie, "SELECT id_producent, producent, email, telefon, miejscowosc, ulica, numer FROM producenci WHERE id_producent='$num'");
		$liczba_rekordow = mysqli_num_rows($wybierz);
		while ($wynik = @mysqli_fetch_array($wybierz,  MYSQLI_ASSOC)) {
			$id_producent=$wynik['id_producent'];
			$producent=$wynik['producent'];
			$email=$wynik['email'];
			$telefon=$wynik['telefon'];
			$miejscowosc=$wynik['miejscowosc'];
			$ulica=$wynik['ulica'];
			$numer=$wynik['numer'];
		}
	}
	if(isset($_POST['producentP'],$_POST['emailP'],$_POST['telefonP'],$_POST['miejscowoscP'],$_POST['ulicaP'],$_POST['numerP']))	
	{
		$id_producentP = $id_producent;
		$producentP = $_POST['producentP'];
		$emailP = $_POST['emailP'];
		$telefonP = $_POST['telefonP'];
		$miejscowoscP = $_POST['miejscowoscP'];
		$ulicaP = $_POST['ulicaP'];
		$numerP = $_POST['numerP'];
		mysqli_query($polaczenie, "UPDATE producenci SET producent='$producentP', email='$emailP', telefon='$telefonP', miejscowosc='$miejscowoscP', ulica='$ulicaP', numer='$numerP' WHERE id_producent=$id_producentP;");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Id:<br /><input id="ident1" type="text" name="id_producentP" Value='<?php echo $id_producent;?>' disabled><br />
		Producent:<br /><input type="text" name="producentP" Value='<?php echo $producent;?>'><br />
		Email:<br /><input type="text" name="emailP" Value='<?php echo $email;?>'><br />
		telefon:<br /><input type="text" name="telefonP" Value='<?php echo $telefon;?>'><br /><br />
		miejscowosc:<br /><input type="text" name="miejscowoscP" Value='<?php echo $miejscowosc;?>'><br /><br />
		ulica:<br /><input type="text" name="ulicaP" Value='<?php echo $ulica;?>'><br /><br />
		numer:<br /><input type="text" name="numerP" Value='<?php echo $numer;?>'><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>