<?php
	require_once "connect.php";
	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: login.php');
		exit();
	}
	//else if(isset($_SESSION['zalogowany']) && $_SESSION['login']<=>'admin')
	//{
	//	header('Location: index.php');
	//	exit();
	//}
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);	

	echo "<p>Witaj ".$_SESSION['login'].'! [ <a href="wyloguj.php">Wyloguj się!</a> ]</p>';
	if(isset($_GET['ident5']))
	{
		$num=$_GET['ident5'];

		$wybierz = mysqli_query($polaczenie, "SELECT id_komputer, id_kategoria, nazwa, id_cpu, id_ram, id_gpu id_mobo, id_zasilacz, id_dysk, id_obudowa, cena, ilosc, opis, dodatki FROM komputery WHERE id_komputer='$num'");
		$liczba_rekordow = mysqli_num_rows($wybierz);
		while ($wynik = @mysqli_fetch_array($wybierz,  MYSQLI_ASSOC)) {
			$id_komputer=$wynik['id_komputer'];
			$kategoria=$wynik['id_kategoria'];
			$nazwa=$wynik['nazwa'];
			$id_cpu=$wynik['id_cpu'];
			$id_ram=$wynik['id_ram'];
			$id_gpu=$wynik['id_gpu'];
			$id_mobo=$wynik['id_mobo'];
			$id_zasilacz=$wynik['id_zasilacz'];
			$id_dysk=$wynik['id_dysk'];
			$id_obudowa=$wynik['id_obudowa'];
			$cena=$wynik['cena'];
			$ilosc=$wynik['ilosc'];
			$opis=$wynik['opis'];
			$dodatki=$wynik['dodatki'];
		}
	}
	if(isset($_POST['kategoriaP'],$_POST['nazwaP'],$_POST['id_cpuP'],$_POST['id_ramP'],$_POST['id_gpuP'],$_POST['id_moboP'],$_POST['id_zasilaczP'],$_POST['id_dyskP'],$_POST['id_obudowaP'],$_POST['cenaP'],$_POST['iloscP'],$_POST['opisP'],$_POST['dodatkiP']))	
	{
		$id_komputerP = $id_komputer;
		$kategoriaP = $_POST['kategoriaP'];
		$nazwaP = $_POST['nazwaP'];
		$id_cpuP = $_POST['id_cpuP'];
		$id_ramP = $_POST['id_ramP'];
		$id_gpuP = $_POST['id_gpuP'];
		$id_moboP = $_POST['id_moboP'];
		$id_zasilaczP = $_POST['id_zasilaczP'];
		$id_dyskP = $_POST['id_dyskP'];
		$id_obudowaP = $_POST['id_obudowaP'];
		$cenaP= $_POST['cenaP'];
		$iloscP = $_POST['iloscP'];
		$opisP = $_POST['opisP'];
		$dodatkiP = $_POST['dodatkiP'];
		mysqli_query($polaczenie, "UPDATE komputery SET id_kategoria='$kategoriaP', nazwa='$nazwaP', id_cpu='$id_cpuP', id_ram='$id_ramP', id_gpu='$id_gpuP', id_mobo='$id_moboP', id_zasilacz='$id_zasilaczP', id_dysk='$id_dyskP', id_obudowa='$id_obudowaP', cena='$cenaP', ilosc='$iloscP', opis='$opisP', dodatki='$dodatkiP' WHERE id_komputer=$id_komputerP;");
		echo "<script>window.close();</script>";
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Panel administratora</title>
</head>
<body>
	<br />
	<form method="post">
		Id:<br /><input id="ident5" type="text" name="id_komputerp" Value='<?php echo $id_komputer;?>' disabled><br />
		id kategoria:<br /><input type="text" name="kategoriaP" Value='<?php echo $kategoria;?>'><br />
		nazwa:<br /><input type="text" name="nazwaP" Value='<?php echo $nazwa;?>'><br />
		Id cpu:<br /><input type="text" name="id_cpuP" Value='<?php echo $id_cpu;?>'><br /><br />
		Id ram:<br /><input type="text" name="id_ramP" Value='<?php echo $id_ram;?>'><br /><br />
		Id gpu:<br /><input type="text" name="id_gpuP" Value='<?php echo $id_gpu;?>'><br /><br />
		Id mobo:<br /><input type="text" name="id_moboP" Value='<?php echo $id_mobo;?>'><br /><br />
		Id zasilacz:<br /><input type="text" name="id_zasilaczP" Value='<?php echo $id_zasilacz;?>'><br /><br />
		Id dysk:<br /><input type="text" name="id_dyskP" Value='<?php echo $id_dysk;?>'><br />
		Id obudowa:<br /><input type="text" name="id_obudowaP" Value='<?php echo $id_obudowa;?>'><br />
		cena:<br /><input type="text" name="cenaP" Value='<?php echo $cena;?>'><br /><br />
		ilosc:<br /><input type="text" name="iloscP" Value='<?php echo $ilosc;?>'><br /><br />
		opis:<br /><input type="text" name="opisP" Value='<?php echo $opis;?>'><br /><br />
		dodatki:<br /><input type="text" name="dodatkiP" Value='<?php echo $dodatki;?>'><br /><br />
		<input type="submit" value="zapisz">
	</form>
</body>